package net.ravadael.dimensionhouse.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.ravadael.dimensionhouse.blockentity.HousePortalBlockEntity;
import net.ravadael.dimensionhouse.world.HouseTeleporter;
import net.minecraft.world.level.block.EntityBlock;

import javax.annotation.Nullable;

public class HouseReturnPortalBlock extends Block implements EntityBlock {

    private static final String NBT_PORTAL_CD = "dimensionhouse:portal_cd";

    public HouseReturnPortalBlock(Properties props) {
        super(props);
    }

    // ✅ Bloc traversable : collision vide
    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return Shapes.empty();
    }

    // ✅ Pas d’occlusion (pour que ce ne soit pas considéré comme bloc “plein”)
    @Override
    public VoxelShape getOcclusionShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    // (Optionnel mais propre) : aussi vide pour le rendu/selection
    @Override
    public VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return Shapes.empty();
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide) return;
        if (!(entity instanceof ServerPlayer player)) return;

        if (!player.level().dimension().equals(HouseTeleporter.HOUSE_DIMENSION)) return;

        var nbt = player.getPersistentData();
        long gameTime = level.getGameTime();

        if (nbt.contains(NBT_PORTAL_CD) && gameTime < nbt.getLong(NBT_PORTAL_CD)) return;
        nbt.putLong(NBT_PORTAL_CD, gameTime + 20);

        HouseTeleporter.handleTeleportKey(player);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new HousePortalBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return null; // pas de tick BE nécessaire
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE; // on cache le modèle JSON
    }

}

