package net.ravadael.dimensionhouse.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.ravadael.dimensionhouse.blockentity.HousePortalBlockEntity;

public class HousePortalBER implements BlockEntityRenderer<HousePortalBlockEntity> {

    @Override
    public void render(HousePortalBlockEntity be, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer,
                       int packedLight, int packedOverlay) {

        poseStack.pushPose();

        VertexConsumer vc = buffer.getBuffer(RenderType.endPortal());
        PoseStack.Pose last = poseStack.last();

        int overlay = OverlayTexture.NO_OVERLAY;

        // On dessine une surface fine (comme le vrai end portal)
        float y = 0.75f;      // hauteur du “plancher” du portail
        float min = 0.0f;
        float max = 1.0f;

        float nx = 0f, ny = 1f, nz = 0f; // normale vers le haut

        // Quad horizontal
        vc.vertex(last.pose(), min, y, min).color(255,255,255,255).uv(0,0).overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();
        vc.vertex(last.pose(), max, y, min).color(255,255,255,255).uv(1,0).overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();
        vc.vertex(last.pose(), max, y, max).color(255,255,255,255).uv(1,1).overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();
        vc.vertex(last.pose(), min, y, max).color(255,255,255,255).uv(0,1).overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();

        poseStack.popPose();
    }
}
