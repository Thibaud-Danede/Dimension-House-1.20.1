package net.ravadael.dimensionhouse.worldgen.travel;

public class ModTeleporter {
}
