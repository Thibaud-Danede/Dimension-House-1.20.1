package net.ravadael.dimensionhouse.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.ravadael.dimensionhouse.DimensionHouse;
import net.ravadael.dimensionhouse.entity.RiftEntity;

public class RiftRenderer extends EntityRenderer<RiftEntity> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(DimensionHouse.MOD_ID, "textures/entity/rift.png");

    private static final ResourceLocation GLOW_TEX =
            new ResourceLocation(DimensionHouse.MOD_ID, "textures/entity/rift_glow.png");

    // ✅ texture cassure
    private static final ResourceLocation CRACK_TEX =
            new ResourceLocation(DimensionHouse.MOD_ID, "textures/entity/rift_crack.png");

    private static final int LIFETIME_TICKS = 20 * 30; // 30s

    // --------- Forme pupille en bandes ----------
    private static final int STRIPS = 21;
    private static final float RX = 0.28f;
    private static final float RY = 0.90f;
    private static final float PINCH_POWER = 2.4f;
    private static final float VERTICAL_POWER = 1.7f;

    // --------- Timing ouverture/fermeture ----------
    private static final float OPEN_END = 0.10f;
    private static final float CLOSE_START = 0.88f;
    private static final float CLOSE_DUR = 0.10f;

    private static final float LENGTH_FACTOR = 1.05f;

    // ✅ phase cassure : 4% de vie ≈ 24 ticks
    private static final float CRACK_END = 0.04f;

    public RiftRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public void render(RiftEntity entity, float entityYaw, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {

        poseStack.pushPose();

        // centre vertical
        poseStack.translate(0.0, entity.getBbHeight() / 2.0, 0.0);

        // orientation yaw réel (pas billboard)
        float yaw = Mth.rotLerp(partialTicks, entity.yRotO, entity.getYRot());
        poseStack.mulPose(Axis.YP.rotationDegrees(-yaw));

        float time = entity.tickCount + partialTicks;
        float life = clamp01(time / LIFETIME_TICKS);

        PoseStack.Pose last = poseStack.last();
        int overlay = OverlayTexture.NO_OVERLAY;

        // =========================
        // PHASE 0 : CASSURE SEULE
        // =========================
        if (life < CRACK_END) {
            float crackT = clamp01(life / CRACK_END);  // 0 -> 1
            float crackAlpha = (1.0f - crackT);        // fade-out

            // petit flash au spawn
            float flash = 0.8f + 0.4f * (1.0f - crackT);
            poseStack.scale(flash, flash, flash);

            VertexConsumer crackVc = buffer.getBuffer(RenderType.entityTranslucent(CRACK_TEX));
            renderCrackBurst(crackVc, last, crackT, crackAlpha, packedLight, overlay);

            poseStack.popPose();
            return;
        }

        // =========================
        // PHASE 1 : OUVERTURE PUPILLE
        // =========================

        float openT = clamp01(life / OPEN_END);
        float open = easeInQuart(openT);

        float closeT = clamp01((life - CLOSE_START) / CLOSE_DUR);
        float close = 1.0f - easeInQuart(closeT);

        float aperture = clamp01(open * close);

        if (aperture < 0.005f) {
            poseStack.popPose();
            return;
        }

        float base = 2.0F;
        float widthFactor  = 0.001f + 0.999f * aperture;
        float heightFactor = 1.00f;

        poseStack.scale(base * widthFactor, base * heightFactor * LENGTH_FACTOR, base);

        last = poseStack.last();
        float alpha = smoothFade(life);

        // ----- PASS 1 : centre endPortal -----
        VertexConsumer vc = buffer.getBuffer(RenderType.endPortal());

        renderPupilStripsLayer(vc, last, RX * 1.00f, RY * 1.00f, PINCH_POWER, VERTICAL_POWER,
                packedLight, overlay, alpha, 0.000f);

        renderPupilStripsLayer(vc, last, RX * 0.82f, RY * 0.82f, PINCH_POWER, VERTICAL_POWER,
                packedLight, overlay, alpha * 0.85f, 0.010f);

        renderPupilStripsLayer(vc, last, RX * 0.65f, RY * 0.65f, PINCH_POWER, VERTICAL_POWER,
                packedLight, overlay, alpha * 0.70f, 0.020f);

        // ----- PASS 2 : halo glow -----
        VertexConsumer glow = buffer.getBuffer(RenderType.entityTranslucent(GLOW_TEX));

        renderGlowQuad(glow, last,
                RX * 1.55f,
                RY * 1.30f,
                packedLight, overlay,
                alpha * 0.45f, 0.040f);

        renderGlowQuad(glow, last,
                RX * 1.85f,
                RY * 1.30f,
                packedLight, overlay,
                alpha * 0.22f, 0.050f);

        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    // ============================================================
    // CASSURE : burst sans rotation
    // ============================================================

    /** Burst de fissures : 6 quads fins fixes */
    private static void renderCrackBurst(VertexConsumer vc, PoseStack.Pose last,
                                         float t, float alpha,
                                         int packedLight, int overlay) {

        int a = (int)(alpha * 255);
        int r = 255, g = 255, b = 255;

        int cracks = 6;
        float baseLen = 0.6f + 0.8f * t; // grandit vite
        float thickness = 0.03f;

        // angles fixes (pas d’animation rotative)
        for (int i = 0; i < cracks; i++) {
            float ang = (360f / cracks) * i + 15f; // petit tilt constant
            float rad = (float) Math.toRadians(ang);

            float dx = (float)Math.cos(rad) * baseLen;
            float dy = (float)Math.sin(rad) * baseLen;

            putThinQuad(vc, last,
                    -dx, -dy, dx, dy,
                    thickness,
                    r,g,b,a,
                    packedLight, overlay,
                    0.035f);
        }
    }

    /** Quad fin type fissure */
    private static void putThinQuad(VertexConsumer vc, PoseStack.Pose last,
                                    float x0, float y0, float x1, float y1,
                                    float thickness,
                                    int r,int g,int b,int a,
                                    int packedLight, int overlay,
                                    float z) {

        float vx = x1 - x0;
        float vy = y1 - y0;
        float len = (float)Math.sqrt(vx*vx + vy*vy);
        if (len < 1e-4f) return;

        float nx = -vy / len * thickness;
        float ny =  vx / len * thickness;

        float ax = x0 + nx, ay = y0 + ny;
        float bx = x0 - nx, by = y0 - ny;
        float cx = x1 - nx, cy = y1 - ny;
        float dx = x1 + nx, dy = y1 + ny;

        // avant
        vc.vertex(last.pose(), ax, ay, z).color(r,g,b,a).uv(0,1).overlayCoords(overlay).uv2(packedLight)
                .normal(last.normal(), 0,0,1).endVertex();
        vc.vertex(last.pose(), bx, by, z).color(r,g,b,a).uv(1,1).overlayCoords(overlay).uv2(packedLight)
                .normal(last.normal(), 0,0,1).endVertex();
        vc.vertex(last.pose(), cx, cy, z).color(r,g,b,a).uv(1,0).overlayCoords(overlay).uv2(packedLight)
                .normal(last.normal(), 0,0,1).endVertex();
        vc.vertex(last.pose(), dx, dy, z).color(r,g,b,a).uv(0,0).overlayCoords(overlay).uv2(packedLight)
                .normal(last.normal(), 0,0,1).endVertex();

        // arrière
        vc.vertex(last.pose(), dx, dy, z).color(r,g,b,a).uv(0,0).overlayCoords(overlay).uv2(packedLight)
                .normal(last.normal(), 0,0,-1).endVertex();
        vc.vertex(last.pose(), cx, cy, z).color(r,g,b,a).uv(1,0).overlayCoords(overlay).uv2(packedLight)
                .normal(last.normal(), 0,0,-1).endVertex();
        vc.vertex(last.pose(), bx, by, z).color(r,g,b,a).uv(1,1).overlayCoords(overlay).uv2(packedLight)
                .normal(last.normal(), 0,0,-1).endVertex();
        vc.vertex(last.pose(), ax, ay, z).color(r,g,b,a).uv(0,1).overlayCoords(overlay).uv2(packedLight)
                .normal(last.normal(), 0,0,-1).endVertex();
    }

    // ============================================================
    // Pupille strips (inchangé)
    // ============================================================

    private static void renderPupilStripsLayer(VertexConsumer vc, PoseStack.Pose last,
                                               float rx, float ry,
                                               float pinchPower, float verticalPower,
                                               int packedLight, int overlay,
                                               float alpha, float zOffset) {

        int a = (int)(alpha * 255);
        int r = 255, g = 255, b = 255;

        int halfStrips = STRIPS / 2;
        float stripWidth = (2f * rx) / STRIPS;

        for (int i = -halfStrips; i <= halfStrips; i++) {

            float xCenter = i * stripWidth;
            float x0 = xCenter - stripWidth / 2f;
            float x1 = xCenter + stripWidth / 2f;

            float nx01 = xCenter / rx;
            float absNx = Math.abs(nx01);

            float profile = (float)Math.sqrt(Math.max(0f, 1f - absNx * absNx));
            profile = (float)Math.pow(profile, 1f / pinchPower);
            profile = (float)Math.pow(profile, verticalPower);

            float yHalf = ry * profile;
            if (yHalf < 0.001f) continue;

            float nxf = 0f, nyf = 0f, nzf = 1f;

            vc.vertex(last.pose(), x0, -yHalf, zOffset).color(r,g,b,a).uv(0,1)
                    .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nxf, nyf, nzf).endVertex();
            vc.vertex(last.pose(), x1, -yHalf, zOffset).color(r,g,b,a).uv(1,1)
                    .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nxf, nyf, nzf).endVertex();
            vc.vertex(last.pose(), x1,  yHalf, zOffset).color(r,g,b,a).uv(1,0)
                    .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nxf, nyf, nzf).endVertex();
            vc.vertex(last.pose(), x0,  yHalf, zOffset).color(r,g,b,a).uv(0,0)
                    .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nxf, nyf, nzf).endVertex();

            nzf = -1f;

            vc.vertex(last.pose(), x0,  yHalf, zOffset).color(r,g,b,a).uv(0,0)
                    .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nxf, nyf, nzf).endVertex();
            vc.vertex(last.pose(), x1,  yHalf, zOffset).color(r,g,b,a).uv(1,0)
                    .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nxf, nyf, nzf).endVertex();
            vc.vertex(last.pose(), x1, -yHalf, zOffset).color(r,g,b,a).uv(1,1)
                    .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nxf, nyf, nzf).endVertex();
            vc.vertex(last.pose(), x0, -yHalf, zOffset).color(r,g,b,a).uv(0,1)
                    .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nxf, nyf, nzf).endVertex();
        }
    }

    // ============================================================
    // Glow quad (inchangé)
    // ============================================================

    private static void renderGlowQuad(VertexConsumer vc, PoseStack.Pose last,
                                       float rx, float ry,
                                       int packedLight, int overlay,
                                       float alpha, float zOffset) {

        int a = (int)(alpha * 255);
        int r = 255, g = 255, b = 255;

        float x0 = -rx;
        float x1 =  rx;
        float y0 = -ry;
        float y1 =  ry;

        float nx = 0f, ny = 0f, nz = 1f;

        vc.vertex(last.pose(), x0, y0, zOffset).color(r,g,b,a).uv(0, 1)
                .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();
        vc.vertex(last.pose(), x1, y0, zOffset).color(r,g,b,a).uv(1, 1)
                .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();
        vc.vertex(last.pose(), x1, y1, zOffset).color(r,g,b,a).uv(1, 0)
                .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();
        vc.vertex(last.pose(), x0, y1, zOffset).color(r,g,b,a).uv(0, 0)
                .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();

        nz = -1f;

        vc.vertex(last.pose(), x0, y1, zOffset).color(r,g,b,a).uv(0, 0)
                .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();
        vc.vertex(last.pose(), x1, y1, zOffset).color(r,g,b,a).uv(1, 0)
                .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();
        vc.vertex(last.pose(), x1, y0, zOffset).color(r,g,b,a).uv(1, 1)
                .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();
        vc.vertex(last.pose(), x0, y0, zOffset).color(r,g,b,a).uv(0, 1)
                .overlayCoords(overlay).uv2(packedLight).normal(last.normal(), nx, ny, nz).endVertex();
    }

    // ============================================================

    private static float smoothFade(float life01) {
        float fadeInEnd = 0.10f;
        float fadeOutStart = CLOSE_START;

        if (life01 < fadeInEnd) {
            float t = life01 / fadeInEnd;
            return t * t * (3 - 2 * t);
        }
        if (life01 > fadeOutStart) {
            float t = (1.0f - life01) / (1.0f - fadeOutStart);
            return t * t * (3 - 2 * t);
        }
        return 1.0f;
    }

    private static float easeInQuart(float t) {
        return t * t * t * t;
    }

    private static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    @Override
    public ResourceLocation getTextureLocation(RiftEntity entity) {
        return TEXTURE;
    }
}
