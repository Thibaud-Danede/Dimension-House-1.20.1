package net.ravadael.dimensionhouse.entity;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;
import net.ravadael.dimensionhouse.world.HouseTeleporter;
import org.joml.Vector3f;

public class RiftEntity extends Entity {

    private static final int LIFETIME_TICKS = 20 * 30; // 30 secondes
    private static final String NBT_RIFT_CD = "dimensionhouse:rift_cd";

    // ✅ phase cassure: 4% de vie ≈ 24 ticks
    private static final float CRACK_END = 0.04f;

    public RiftEntity(EntityType<? extends RiftEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    @Override
    protected void defineSynchedData() {}

    @Override
    public void tick() {
        super.tick();

        // =========================
        // ✅ CLIENT : particules
        // =========================
        if (level().isClientSide) {
            float life = clamp01(this.tickCount / (float)LIFETIME_TICKS);

            if (life < CRACK_END) {
                spawnCrackParticles(life);
            } else {
                spawnOutlineParticles(life);
            }
            return;
        }

        // =========================
        // ✅ SERVEUR : lifetime + TP
        // =========================
        if (this.tickCount >= LIFETIME_TICKS) {
            this.discard();
            return;
        }

        var players = level().getEntitiesOfClass(ServerPlayer.class, this.getBoundingBox());
        for (ServerPlayer p : players) {

            long now = level().getGameTime();
            var nbt = p.getPersistentData();

            // cooldown 1s pour éviter TP en boucle
            if (nbt.contains(NBT_RIFT_CD) && now < nbt.getLong(NBT_RIFT_CD)) {
                continue;
            }
            nbt.putLong(NBT_RIFT_CD, now + 20);

            HouseTeleporter.handleTeleportKey(p);
        }
    }

    /** ✅ Petits éclats violents au tout début */
    private void spawnCrackParticles(float life) {

        // intensité décroissante
        float t = 1.0f - (life / CRACK_END);

        DustParticleOptions violet = new DustParticleOptions(
                new Vector3f(0.6f, 0.2f, 0.9f),
                1.0f + t * 0.6f
        );

        double baseY = this.getY() + this.getBbHeight() * 0.6;

        int count = 6 + (int)(t * 8); // plus dense au début

        for (int i = 0; i < count; i++) {
            double ox = (random.nextDouble() - 0.5) * 0.8;
            double oy = (random.nextDouble() - 0.5) * 0.8;
            double oz = (random.nextDouble() - 0.5) * 0.2;

            double px = getX() + ox;
            double py = baseY + oy;
            double pz = getZ() + oz;

            // spark lumineux
            level().addParticle(ParticleTypes.ELECTRIC_SPARK,
                    px, py, pz,
                    (random.nextDouble() - 0.5) * 0.02,
                    random.nextDouble() * 0.03,
                    (random.nextDouble() - 0.5) * 0.02);

            // poussière violette
            if (random.nextFloat() < 0.6f) {
                level().addParticle(violet, px, py, pz, 0, 0, 0);
            }
        }
    }

    private void spawnOutlineParticles(float life) {

        DustParticleOptions violet = new DustParticleOptions(
                new Vector3f(0.6f, 0.2f, 0.9f),
                1.2f
        );

        float openT = clamp01(life / 0.10f);
        float open = openT * openT * openT * openT;

        float closeT = clamp01((life - 0.88f) / 0.10f);
        float close = 1.0f - (closeT * closeT * closeT * closeT);

        float aperture = clamp01(open * close);
        if (aperture < 0.01f) return;

        double rx = 0.28 * 2.0 * aperture;
        double ry = 0.90 * 2.0 * 1.05;

        double baseY = this.getY() + this.getBbHeight() * 0.5 + 0.10;

        for (int k = 0; k < 5; k++) {

            double x = (random.nextDouble() * 2 - 1) * rx;
            double absNx = Math.abs(x / rx);

            double profile = Math.sqrt(Math.max(0.0, 1.0 - absNx * absNx));
            profile = Math.pow(profile, 1.0 / 2.4);
            profile = Math.pow(profile, 1.7);

            double yHalf = ry * profile;
            if (yHalf < 0.02) continue;

            double sign = random.nextBoolean() ? 1.0 : -1.0;
            double edgeBias = 0.65 + 0.35 * random.nextDouble();
            double y = sign * yHalf * edgeBias;

            x += (random.nextDouble() - 0.5) * 0.10;
            y += (random.nextDouble() - 0.5) * 0.08;

            float yaw = this.getYRot();
            double rad = Math.toRadians(-yaw);
            double cos = Math.cos(rad);
            double sin = Math.sin(rad);

            double xWorld = x * cos;
            double zWorld = x * sin;

            double px = this.getX() + xWorld;
            double py = baseY + y;
            double pz = this.getZ() + zWorld;

            level().addParticle(violet, px, py, pz, 0, 0, 0);

            if (random.nextFloat() < 0.20f) {
                level().addParticle(ParticleTypes.PORTAL, px, py, pz, 0, 0, 0);
            }
        }
    }

    private static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
